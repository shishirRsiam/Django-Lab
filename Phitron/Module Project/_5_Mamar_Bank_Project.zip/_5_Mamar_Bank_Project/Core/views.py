from django.shortcuts import render
from Transactions .models import Loan

