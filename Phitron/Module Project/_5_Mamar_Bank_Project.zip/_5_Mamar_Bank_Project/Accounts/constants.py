

ACCOUNT_TYPE = [('Savings', 'Savings'), 
                ('Checking', 'Checking'), 
                ('Credit Card', 'Credit Card')]
GENDER = [('Male', 'Male'), ('Female', 'Female'), ('Other', 'Other')]